import React from 'react'

import { IoMenu, IoSearch } from "react-icons/io5";
import { CgProfile } from "react-icons/cg";
import { GoHeartFill } from "react-icons/go";
import { FaCartShopping } from "react-icons/fa6";

const HeaderMobile = () => {
  return (
    <div>HeaderMobile</div>
  )
}

export default HeaderMobile