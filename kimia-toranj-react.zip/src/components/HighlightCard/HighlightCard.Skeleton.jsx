// src/components/HighlightCard/HighlightCard.Skeleton.jsx
import React from 'react';
import styles from './HighlightCard.module.css'; // for sizing & layout

export default function HighlightCardSkeleton() {
  return (
    <div className={styles.card}>
      {/* circle placeholder for the image */}
      <div
        className="skeleton"
        style={{
          width: styles.imageContainer.replace(/[^0-9]/g, '') + 'px',
          height: styles.imageContainer.replace(/[^0-9]/g, '') + 'px',
          borderRadius: '50%',
        }}
      />

      {/* line placeholder for the title */}
      <div
        className="skeleton"
        style={{
          width: '70%',
          height: '16px',
          marginTop: '8px',
        }}
      />
    </div>
  );
}
